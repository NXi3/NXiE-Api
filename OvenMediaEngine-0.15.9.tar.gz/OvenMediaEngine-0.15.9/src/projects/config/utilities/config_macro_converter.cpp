//==============================================================================
//
//  OvenMediaEngine
//
//  Created by Gil Hoon Choi
//  Copyright (c) 2018 AirenSoft. All rights reserved.
//
//==============================================================================
#include "config_macro_converter.h"

ConfigMacroConverter::ConfigMacroConverter()
{
}

ConfigMacroConverter::~ConfigMacroConverter()
{
}