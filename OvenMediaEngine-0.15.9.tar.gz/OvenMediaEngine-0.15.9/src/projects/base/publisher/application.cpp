#include "application.h"

#include <algorithm>

#include "publisher.h"
#include "publisher_private.h"

namespace pub
{
	ApplicationWorker::ApplicationWorker(uint32_t worker_id, ov::String worker_name)
		: _stream_data_queue(nullptr, 500)
	{
		_worker_id = worker_id;
		_worker_name = worker_name;
		_stop_thread_flag = false;
	}

	bool ApplicationWorker::Start()
	{
		_stop_thread_flag = false;
		_worker_thread = std::thread(&ApplicationWorker::WorkerThread, this);
		pthread_setname_np(_worker_thread.native_handle(), ov::String::FormatString("AW-%s%d", _worker_name.CStr(), _worker_id).CStr());

		ov::String queue_name;

		queue_name.Format("%s - Stream Data Queue", _worker_name.CStr());
		_stream_data_queue.SetAlias(queue_name.CStr());

		logtd("%s ApplicationWorker has been created", _worker_name.CStr());

		return true;
	}

	bool ApplicationWorker::Stop()
	{
		if (_stop_thread_flag == true)
		{
			return true;
		}

		_stream_data_queue.Clear();

		_stop_thread_flag = true;

		_queue_event.Notify();

		if (_worker_thread.joinable())
		{
			_worker_thread.join();
		}

		return true;
	}

	bool ApplicationWorker::PushMediaPacket(const std::shared_ptr<Stream> &stream, const std::shared_ptr<MediaPacket> &media_packet)
	{
		auto data = std::make_shared<ApplicationWorker::StreamData>(stream, media_packet);
		_stream_data_queue.Enqueue(std::move(data));

		_queue_event.Notify();

		return true;
	}

	std::shared_ptr<ApplicationWorker::StreamData> ApplicationWorker::PopStreamData()
	{
		if (_stream_data_queue.IsEmpty())
		{
			return nullptr;
		}

		auto data = _stream_data_queue.Dequeue(0);
		if (data.has_value())
		{
			return data.value();
		}

		return nullptr;
	}

	void ApplicationWorker::WorkerThread()
	{
		while (!_stop_thread_flag)
		{
			_queue_event.Wait();

			// Check media data is available
			auto stream_data = PopStreamData();
			if ((stream_data != nullptr) && (stream_data->_stream != nullptr) && (stream_data->_media_packet != nullptr))
			{
				if (stream_data->_media_packet->GetMediaType() == cmn::MediaType::Video)
				{
					stream_data->_stream->SendVideoFrame(stream_data->_media_packet);
				}
				else if (stream_data->_media_packet->GetMediaType() == cmn::MediaType::Audio)
				{
					stream_data->_stream->SendAudioFrame(stream_data->_media_packet);
				}
				else if (stream_data->_media_packet->GetMediaType() == cmn::MediaType::Data)
				{
					stream_data->_stream->SendDataFrame(stream_data->_media_packet);
				}
				else
				{
					// Nothing can do
				}
			}
		}
	}

	Application::Application(const std::shared_ptr<Publisher> &publisher, const info::Application &application_info)
		: info::Application(application_info)
	{
		_publisher = publisher;
	}

	Application::~Application()
	{
		Stop();
	}

	const char *Application::GetApplicationTypeName()
	{
		if (_publisher == nullptr)
		{
			return "";
		}

		if (_app_type_name.IsEmpty())
		{
			_app_type_name.Format("%s %s", _publisher->GetPublisherName(), "Application");
		}

		return _app_type_name.CStr();
	}

	bool Application::Start()
	{
		_application_worker_count = GetConfig().GetAppWorkerCount();
		if (_application_worker_count < MIN_APPLICATION_WORKER_COUNT)
		{
			_application_worker_count = MIN_APPLICATION_WORKER_COUNT;
		}
		if (_application_worker_count > MAX_APPLICATION_WORKER_COUNT)
		{
			_application_worker_count = MAX_APPLICATION_WORKER_COUNT;
		}

		std::lock_guard<std::shared_mutex> worker_lock(_application_worker_lock);

		for (uint32_t i = 0; i < _application_worker_count; i++)
		{
			auto app_worker = std::make_shared<ApplicationWorker>(i, StringFromPublisherType(_publisher->GetPublisherType()).CStr());
			if (app_worker->Start() == false)
			{
				logte("Cannot create ApplicationWorker (%s/%s/%d)", GetApplicationTypeName(), GetName().CStr(), i);
				Stop();

				return false;
			}

			_application_workers.push_back(app_worker);
		}

		logti("%s has created [%s] application", GetApplicationTypeName(), GetName().CStr());

		return true;
	}

	bool Application::Stop()
	{
		std::unique_lock<std::shared_mutex> worker_lock(_application_worker_lock);
		for (const auto &worker : _application_workers)
		{
			worker->Stop();
		}

		_application_workers.clear();
		worker_lock.unlock();

		// release remaining streams
		DeleteAllStreams();

		logti("%s has deleted [%s] application", GetApplicationTypeName(), GetName().CStr());

		return true;
	}

	bool Application::DeleteAllStreams()
	{
		std::unique_lock<std::shared_mutex> lock(_stream_map_mutex);

		for (const auto &x : _streams)
		{
			auto stream = x.second;
			stream->Stop();
		}

		_streams.clear();

		return true;
	}

	// Called by MediaRouteApplicationObserver
	bool Application::OnStreamCreated(const std::shared_ptr<info::Stream> &info)
	{
		auto stream_worker_count = GetConfig().GetStreamWorkerCount();

		auto stream = CreateStream(info, stream_worker_count);
		if (!stream)
		{
			return false;
		}

		std::lock_guard<std::shared_mutex> lock(_stream_map_mutex);
		_streams[info->GetId()] = stream;

		return true;
	}

	bool Application::OnStreamDeleted(const std::shared_ptr<info::Stream> &info)
	{
		std::unique_lock<std::shared_mutex> lock(_stream_map_mutex);

		auto stream_it = _streams.find(info->GetId());
		if (stream_it == _streams.end())
		{
			// Sometimes stream rejects stream creation if the input codec is not supported. So this is a normal situation.
			logtd("OnStreamDeleted failed. Cannot find stream : %s/%u", info->GetName().CStr(), info->GetId());
			return true;
		}

		auto stream = stream_it->second;

		lock.unlock();

		if (DeleteStream(info) == false)
		{
			return false;
		}

		lock.lock();
		_streams.erase(info->GetId());

		// Stop stream
		stream->Stop();

		return true;
	}

	bool Application::OnStreamPrepared(const std::shared_ptr<info::Stream> &info)
	{
		std::shared_lock<std::shared_mutex> lock(_stream_map_mutex);

		auto stream_it = _streams.find(info->GetId());
		if (stream_it == _streams.end())
		{
			// Sometimes stream rejects stream creation if the input codec is not supported. So this is a normal situation.
			logtd("OnStreamPrepared failed. Cannot find stream : %s/%u", info->GetName().CStr(), info->GetId());
			return true;
		}

		auto stream = stream_it->second;

		lock.unlock();

		// Start stream
		if (stream->Start() == false)
		{
			stream->SetState(Stream::State::ERROR);
			logtw("%s could not start [%s] stream.", GetApplicationTypeName(), info->GetName().CStr(), info->GetId());
			return false;
		}

		return true;
	}

	bool Application::OnStreamUpdated(const std::shared_ptr<info::Stream> &info)
	{
		std::shared_lock<std::shared_mutex> lock(_stream_map_mutex);

		auto stream_it = _streams.find(info->GetId());
		if (stream_it == _streams.end())
		{
			// Sometimes stream rejects stream creation if the input codec is not supported. So this is a normal situation.
			logtd("OnStreamUpdated failed. Cannot find stream : %s/%u", info->GetName().CStr(), info->GetId());
			return true;
		}

		auto stream = stream_it->second;

		lock.unlock();

		return stream->OnStreamUpdated(info);
	}

	std::shared_ptr<ApplicationWorker> Application::GetWorkerByStreamID(info::stream_id_t stream_id)
	{
		if (_application_worker_count == 0)
		{
			return nullptr;
		}

		std::shared_lock<std::shared_mutex> worker_lock(_application_worker_lock);
		return _application_workers[stream_id % _application_worker_count];
	}

	bool Application::OnSendFrame(const std::shared_ptr<info::Stream> &stream,
								  const std::shared_ptr<MediaPacket> &media_packet)
	{
		auto application_worker = GetWorkerByStreamID(stream->GetId());
		if (application_worker == nullptr)
		{
			return false;
		}

		return application_worker->PushMediaPacket(GetStream(stream->GetId()), media_packet);
	}

	uint32_t Application::GetStreamCount()
	{
		return _streams.size();
	}

	std::shared_ptr<Stream> Application::GetStream(uint32_t stream_id)
	{
		std::shared_lock<std::shared_mutex> lock(_stream_map_mutex);
		auto it = _streams.find(stream_id);
		if (it == _streams.end())
		{
			return nullptr;
		}

		return it->second;
	}

	std::shared_ptr<Stream> Application::GetStream(ov::String stream_name)
	{
		std::shared_lock<std::shared_mutex> lock(_stream_map_mutex);
		for (auto const &x : _streams)
		{
			auto stream = x.second;
			if (stream->GetName() == stream_name)
			{
				return stream;
			}
		}

		return nullptr;
	}

	PushApplication::PushApplication(const std::shared_ptr<Publisher> &publisher, const info::Application &application_info) :
		Application(publisher, application_info)
	{
	}
}  // namespace pub
